def addition(x,y):
    return x+y