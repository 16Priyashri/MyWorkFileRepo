def Multiplication(x,y):
    return x*y