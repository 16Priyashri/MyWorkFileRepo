def subtraction(x,y):
    return x-y